import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up the display
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Displaying Image Multiple Times")

# Load the image
image = pygame.image.load('assets/DroneChicken.png')  # Replace 'image.png' with your image file

# Define the number of times to display the image
num_images = 10

# Define the size of each image (optional: use the original image size)
image_width = image.get_width()
image_height = image.get_height()

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Clear the screen
    screen.fill((255, 255, 255))  # Fill with white

    # Display the image multiple times using a for loop
    for i in range(num_images):
        x = i * (image_width + 10)  # Calculate x position (10 pixels spacing between images)
        y = 100  # Fixed y position

        screen.blit(image, (x, y))  # Draw the image at (x, y)

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()
