import pygame

pygame.init()

size = 500, 500
window = pygame.display.set_mode(size)
clock = pygame.time.Clock()

border = pygame.Rect(0, 0, size[0]-40, 100)
border.center = [size[0] // 2, size[1] // 2]
player_xy = [size[0] // 2, size[1] // 2]
radius = 10
PLAYER_ACCEL, PLAYER_FRICT = 0.5, 0.002
veloc = 0

run = True
while run:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # set acceleration in this frame
    accel = 0
    keys = pygame.key.get_pressed()
    if keys[pygame.K_RIGHT]:
        accel += PLAYER_ACCEL
    if keys[pygame.K_LEFT]:
        accel -= PLAYER_ACCEL
    
    # change velocity by acceleration and reduce dependent on friction
    veloc = (veloc + accel) * (1 - PLAYER_FRICT)
    # change position of player by velocity
    player_xy[0] += veloc

    if player_xy[0] < border.left + radius:
        player_xy[0] = border.left + radius
        veloc = 0
    if player_xy[0] > border.right - radius:
        player_xy[0] = border.right - radius
        veloc = 0

    window.fill(0) 
    pygame.draw.rect(window, (255, 0, 0), border, 1)
    pygame.draw.circle(window, (0, 255, 0), (round(player_xy[0]), round(player_xy[1])), radius)
    pygame.display.flip()