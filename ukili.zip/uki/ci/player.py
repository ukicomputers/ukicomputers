from globals import *

class Player:
    def __init__(self):
        self.img = pg.image.load(ASSET_PATH + "ss.png")
        ww, wh = pg.display.get_surface().get_size()
        self.pos = (wh // 2 - self.img.get_height(), ww - 50)

    def draw(self):
        window.blit(self.img, self.pos)
        