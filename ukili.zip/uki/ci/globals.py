import pygame as pg
import chickens
import player

window = pg.display.set_mode(flags=pg.FULLSCREEN)

REGULAR = 0
SECOND_WAVE = 1
ASTEROIDS = 2

ASSET_PATH = "./assets/"
BKGR_PATH = ASSET_PATH + "bkg.jpg"