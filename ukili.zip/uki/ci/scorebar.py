from globals import *

class Scorebar:
    def __init__(self):
        self.lives = 3
        self.score = 0
        self.img = pg.image.load(ASSET_PATH + "scorebar.png")
    
    def draw(self):
        window.blit()