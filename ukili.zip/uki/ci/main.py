from globals import *

# init window
pg.init()
pg.display.set_caption("Space Roosters")

# Init background
bkgr = pg.image.load(BKGR_PATH)

# init and compile assets
kokoske = chickens.Chickens(ASSET_PATH + "DroneChicken.png", window)
player1 = player.Player()

def handling():
    window.blit(bkgr, (0, 0))
    kokoske.draw()
    pg.display.flip()

running = True
while running:
    window.fill("white")

    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False
        if event.type == pg.KEYDOWN:
            pass

    while not kokoske.slide():
        handling()    
    
    handling()