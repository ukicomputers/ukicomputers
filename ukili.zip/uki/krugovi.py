import pygame as pg
import random

window = pg.display.set_mode((800, 600))

x = random.randint(0, 1000)

running = True
while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False

    window.fill("white")
    
    velicina = x * 100
    for i in range(x):
        pg.draw.circle(window, (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)), (random.randint(0, 800), random.randint(0, 600)), 500, 5)
        velicina -= 100

    pg.display.update()