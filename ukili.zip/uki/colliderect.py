import pygame as pg

pg.init()
window = pg.display.set_mode((800, 600))

def colliderect(source, target):
    return source.collidepoint((target.left, target.top))

while True:
    source = pg.draw.rect(window, "white", pg.Rect(250, 250, 100, 100))
    dest = pg.draw.rect(window, "red", pg.Rect(125, 220, 100, 100))
    
    print(colliderect(source, dest))
    
    pg.display.flip()