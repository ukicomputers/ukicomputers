import pygame

pygame.init()

window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)


class Player:
    def __init__(self, pos, speed):
        self.pos = pos
        self.speed = speed

    def move(self, dx=0, dy=0):
        self.pos = (self.pos[0] + dx, self.pos[1] + dy)

    def draw(self):
        pygame.draw.rect(window, (255, 0, 0), (self.pos[0], self.pos[1], 50, 50))
    
    def shoot(self):
        print("puca")

    def handle_keys(self, keys):
        if keys[pygame.K_LEFT]:
            player.move(-self.speed, 0)
        if keys[pygame.K_RIGHT]:
            player.move(self.speed, 0)
        if keys[pygame.K_UP]:
            player.move(0, -self.speed)
        if keys[pygame.K_DOWN]:
            player.move(0, self.speed)
    
    def handle_events(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.shoot()

player = Player((250, 250), 0.2)
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        player.handle_events(event)

    player.handle_keys(pygame.key.get_pressed())

    window.fill((255, 255, 255))
    player.draw()
    pygame.display.update()

pygame.quit()