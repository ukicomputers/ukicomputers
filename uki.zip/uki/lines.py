import pygame

pygame.init()

width, height = 800, 600
window = pygame.display.set_mode((width, height))
pygame.display.set_caption("Crtanje Linija")

lines = []
drawing = False
start_pos = None

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Levi taster miša
                drawing = True
                start_pos = event.pos
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:  # Levi taster miša
                drawing = False
                end_pos = event.pos
                lines.append((start_pos, end_pos))
        elif event.type == pygame.MOUSEMOTION:
            if drawing:
                end_pos = event.pos
                window.fill((255, 255, 255))
                for line in lines:
                    pygame.draw.line(window, (0, 0, 0), line[0], line[1], 2)
                pygame.draw.line(window, (0, 0, 0), start_pos, end_pos, 2)
                pygame.display.update()

    if not drawing:
        window.fill((255, 255, 255))
        for line in lines:
            pygame.draw.line(window, (0, 0, 0), line[0], line[1], 2)
        pygame.display.update()

pygame.quit()