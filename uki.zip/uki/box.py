import pygame as pg

pg.init()
window = pg.display.set_mode((800, 600))

working = True
while working:
    window.fill("white")

    for event in pg.event.get():
        if event.type == pg.QUIT:
            working = False
        if event.type == pg.MOUSEBUTTONDOWN:
            pg.draw.rect(window, "black", pg.Rect(pg.mouse.get_pos()[0], pg.mouse.get_pos()[1], 10, 10))

    pg.display.update()