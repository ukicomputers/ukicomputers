import pygame

pygame.init()

window = pygame.display.set_mode()

class Bullet:
    def __init__(self):
        

class Player:
    def __init__(self, pos, speed):
        self.pos = pos  # (int,int)
        self.speed = speed
        self.player_events = [pygame.MOUSEBUTTONDOWN]
        self.bullets = []
        self.bullet_speed = []
        self.direction = [1, 0]

    def move(self, dx=0, dy=0):
        self.pos[0] += dx
        self.pos[1] += dy
        self.direction[0] = dx
        self.direction[1] = dy

    def draw(self):
        pygame.draw.rect(window, (255, 0, 0), (self.pos[0], self.pos[1], 50, 50))

    def shoot(self):
        postition = self.pos.copy()
        postition[0] += 20
        postition[1] += 20
        self.bullets.append(postition)
        self.bullet_speed.append(self.direction.copy())

    def update_bullet(self):
        for i in range(len(self.bullets)):
            self.bullets[i][0] += self.bullet_speed[i][0] * 10
            self.bullets[i][1] += self.bullet_speed[i][1] * 10

    def draw_bullet(self):
        for bullet in self.bullets:
            pygame.draw.rect(window, (0, 0, 255), (bullet[0], bullet[1], 10, 10))

    def handle_keys(self, keys):
        x_s = self.speed[0]
        y_s = self.speed[1]
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.move(-x_s, 0)
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.move(x_s, 0)
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self.move(0, -y_s)
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.move(0, y_s)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.shoot()


player = Player([250, 250], (1, 1))
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type in player.player_events:
            player.handle_event(event)

    keys = pygame.key.get_pressed()
    window.fill((255, 255, 255))
    player.handle_keys(keys)
    player.draw()
    player.update_bullet()
    player.draw_bullet()
    pygame.display.update()

pygame.quit()