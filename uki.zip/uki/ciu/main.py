from globals import *

kokoske = chickens.Chickens(ASSET_PATH + "DroneChicken.webp", window)

running = True
while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False

    pg.display.update()
    