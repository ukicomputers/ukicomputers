from globals import *

class Chickens():
    def __init__(self, location, windows):
        self.chickens = []
        img = pg.image.load(location)
        
        for i in range(45):
            self.chickens.append(((img.get_width() + 75) * i, (img.get_height() + 75) * 5 * i))
            img.blit(windows, self.chickens[i])